﻿--This SQL file will create the database 'test' with the following properties

CREATE USER user1;
CREATE USER user2;
CREATE USER user3;