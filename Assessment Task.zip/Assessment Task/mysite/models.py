from django.contrib.auth.models import User

user = User.objects.create_user('user1', 'user1@email.com', 'password')
user.save()

user = User.objects.create_user('user2', 'user2@email.com', 'password')
user.save()

user = User.objects.create_user('user3', 'user3@email.com', 'password')
user.save()